NCERT Biology Class 11 — Chapter 17: Locomotion and Movement

Numbering mapped from the source DOCX figure placement/captions:

17.1 -> Fig_17_1.png
17.2 -> Fig_17_2.png
17.3 -> Fig_17_3.png
17.4 -> Fig_17_4.png
17.5 -> Fig_17_5.png
17.6 -> Fig_17_6.png
17.7 + 17.8 -> Fig_17_7_17_8.png
17.9 + 17.10 -> Fig_17_9_17_10.png

Figures 17.7+17.8 and 17.9+17.10 are preserved as the original composite images from the DOCX.
